namespace FamilyTreeApi.Models.Enums;

public enum UnionType
{
    Marriage = 0,
    CivilUnion = 1,
    Partnership = 2,
    CommonLaw = 3
}
