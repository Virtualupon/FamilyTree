namespace FamilyTreeApi.Models.Enums;

public enum UnionRole
{
    Partner,
    Spouse,
    Husband,
    Wife
}
