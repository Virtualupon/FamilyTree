-- Migration: Add Towns table and TownId to Orgs
-- This migration adds the Town entity for organizing family trees by location

-- Create the Towns table
CREATE TABLE IF NOT EXISTS "Towns" (
    "Id" uuid NOT NULL,
    "Name" character varying(200) NOT NULL,
    "NameEn" character varying(200),
    "NameAr" character varying(200),
    "NameLocal" character varying(200),
    "Description" text,
    "Country" character varying(100),
    "CreatedAt" timestamp without time zone NOT NULL,
    "UpdatedAt" timestamp without time zone NOT NULL,
    CONSTRAINT "PK_Towns" PRIMARY KEY ("Id")
);

-- Create indexes on Towns
CREATE INDEX IF NOT EXISTS "IX_Towns_Name" ON "Towns" ("Name");
CREATE INDEX IF NOT EXISTS "IX_Towns_Country" ON "Towns" ("Country");

-- Add TownId column to Orgs table
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'Orgs' AND column_name = 'TownId'
    ) THEN
        ALTER TABLE "Orgs" ADD COLUMN "TownId" uuid;
    END IF;
END $$;

-- Create index on Orgs.TownId
CREATE INDEX IF NOT EXISTS "IX_Orgs_TownId" ON "Orgs" ("TownId");

-- Add foreign key constraint
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints
        WHERE constraint_name = 'FK_Orgs_Towns_TownId'
    ) THEN
        ALTER TABLE "Orgs"
        ADD CONSTRAINT "FK_Orgs_Towns_TownId"
        FOREIGN KEY ("TownId")
        REFERENCES "Towns" ("Id")
        ON DELETE SET NULL;
    END IF;
END $$;

-- Insert migration history record (optional, for EF Core tracking)
-- INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
-- VALUES ('20251217_AddTowns', '8.0.0');
