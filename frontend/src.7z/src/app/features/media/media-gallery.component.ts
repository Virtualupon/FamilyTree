import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-media-gallery',
  standalone: true,
  imports: [CommonModule],
  template: `<h1>Media Gallery - Coming Soon</h1>`
})
export class MediaGalleryComponent {}
