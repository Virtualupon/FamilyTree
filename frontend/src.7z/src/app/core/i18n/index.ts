export * from './i18n.service';
export type { Language, LanguageConfig } from './i18n.service';
export * from './translate.pipe';
