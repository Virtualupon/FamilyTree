namespace FamilyTreeApi.Models.Enums;

public enum NameType
{
    Primary = 0,
    Alias = 1,
    Maiden = 2,
    Nickname = 3,
    Tribal = 4,
    Clan = 5
}
