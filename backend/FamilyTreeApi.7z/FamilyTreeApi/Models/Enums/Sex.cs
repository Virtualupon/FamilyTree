namespace FamilyTreeApi.Models.Enums;

public enum Sex
{
    Male = 0,
    Female = 1,
    Unknown = 2
}
