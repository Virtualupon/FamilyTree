// src/app/core/models/search.models.ts
import { Sex } from './person.models';

// ============================================================================
// PERSON SEARCH
// ============================================================================

/**
 * Request for unified person search (POST /api/search/persons)
 */
export interface PersonSearchRequest {
  query?: string;
  searchIn?: SearchScript;  // 'auto' | 'arabic' | 'latin' | 'coptic'
  treeId?: string;
  townId?: string;
  familyId?: string;
  sex?: Sex | string;  // Accepts enum or string ('Male', 'Female') for API compatibility
  isLiving?: boolean;
  birthYearFrom?: number;
  birthYearTo?: number;
  page?: number;
  pageSize?: number;
}

export type SearchScript = 'auto' | 'arabic' | 'latin' | 'coptic';

/**
 * Result from person search
 */
export interface PersonSearchResult {
  items: SearchPersonItem[];
  totalCount: number;
  page: number;
  pageSize: number;
  totalPages: number;
  searchDurationMs: number;
}

/**
 * Person item from search results with aggregated names
 */
export interface SearchPersonItem {
  id: string;
  orgId: string;
  familyId: string | null;
  familyName: string | null;
  sex: Sex;
  birthDate: string | null;
  deathDate: string | null;
  birthPlaceId: string | null;
  birthPlaceName: string | null;
  isLiving: boolean;
  names: SearchPersonName[];
  parentCount: number;
  childCount: number;
  spouseCount: number;
  mediaCount: number;
}

/**
 * Name entry from search results
 */
export interface SearchPersonName {
  id: string;
  script: string | null;
  full: string | null;
  given: string | null;
  middle: string | null;
  family: string | null;
  transliteration: string | null;
  type: number;
  isPrimary: boolean;
}

// ============================================================================
// RELATIONSHIP PATH FINDING
// ============================================================================

/**
 * Request to find relationship path between two people
 */
export interface RelationshipPathRequest {
  person1Id: string;
  person2Id: string;
  treeId?: string;
  maxDepth?: number;
}

/**
 * Result of relationship path finding
 */
export interface RelationshipPathResult {
  pathFound: boolean;
  pathLength: number;
  pathNodes: PathNode[];
  pathRelationships: PathRelationship[];
  relationshipSummary: string;
  humanReadableRelationship: string;
}

export interface PathNode {
  personId: string;
  primaryName: string;
  sex: Sex;
  birthYear: number | null;
  isLiving: boolean;
}

export interface PathRelationship {
  fromPersonId: string;
  toPersonId: string;
  relationshipType: string;  // 'parent' | 'child' | 'spouse'
}

// ============================================================================
// FAMILY TREE DATA (for visualization)
// ============================================================================

/**
 * Request for family tree data
 */
export interface FamilyTreeDataRequest {
  rootPersonId: string;
  viewMode?: TreeViewMode;  // 'pedigree' | 'descendants' | 'hourglass'
  generations?: number;
  includeSpouses?: boolean;
}

export type TreeViewMode = 'pedigree' | 'descendants' | 'hourglass';

/**
 * Result containing tree data for visualization
 */
export interface FamilyTreeDataResult {
  rootPersonId: string;
  viewMode: string;
  generationsLoaded: number;
  persons: TreePersonNode[];
  totalPersonCount: number;
}

/**
 * Person node in tree data
 */
export interface TreePersonNode {
  id: string;
  primaryName: string | null;
  sex: Sex;
  birthDate: string | null;
  deathDate: string | null;
  isLiving: boolean;
  generationLevel: number;
  relationshipType: string;  // 'root' | 'ancestor' | 'descendant' | 'spouse'
  parentId: string | null;
  spouseUnionId: string | null;
  names: SearchPersonName[];
}

// ============================================================================
// PERSON DETAILS (complete profile)
// ============================================================================

/**
 * Complete person details with all related data
 */
export interface PersonDetailsResult {
  id: string;
  orgId: string;
  familyId: string | null;
  familyName: string | null;
  sex: Sex;
  birthDate: string | null;
  birthPlaceId: string | null;
  birthPlaceName: string | null;
  deathDate: string | null;
  deathPlaceId: string | null;
  deathPlaceName: string | null;
  occupation: string | null;
  education: string | null;
  religion: string | null;
  nationality: string | null;
  notes: string | null;
  isLiving: boolean;
  names: SearchPersonName[];
  parents: RelatedPerson[];
  children: RelatedPerson[];
  spouses: SpouseInfo[];
  siblings: RelatedPerson[];
}

export interface RelatedPerson {
  id: string;
  primaryName: string | null;
  sex: Sex;
  birthYear: number | null;
  isLiving: boolean;
  relationshipType: string | null;
}

export interface SpouseInfo extends RelatedPerson {
  unionId: string;
  unionType: number;
  marriageDate: string | null;
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Get the primary name from a SearchPersonItem
 */
export function getPrimaryName(person: SearchPersonItem): string {
  const primary = person.names.find(n => n.isPrimary) || person.names[0];
  return primary?.full || 'Unknown';
}

/**
 * Get name in specific script
 */
export function getNameByScript(person: SearchPersonItem, script: string): string | null {
  const name = person.names.find(n => n.script?.toLowerCase() === script.toLowerCase());
  return name?.full || null;
}

/**
 * Get Arabic name if available
 */
export function getArabicName(person: SearchPersonItem): string | null {
  return getNameByScript(person, 'arabic') || getNameByScript(person, 'ar');
}

/**
 * Get Latin/English name if available
 */
export function getLatinName(person: SearchPersonItem): string | null {
  return getNameByScript(person, 'latin') || getNameByScript(person, 'en');
}

/**
 * Get Coptic/Nobiin name if available
 */
export function getCopticName(person: SearchPersonItem): string | null {
  return getNameByScript(person, 'coptic') || getNameByScript(person, 'nobiin');
}

/**
 * Convert SearchPersonItem to PersonListItem format for backward compatibility
 */
export function toPersonListItem(item: SearchPersonItem): import('./person.models').PersonListItem {
  return {
    id: item.id,
    familyId: item.familyId,
    familyName: item.familyName,
    primaryName: getPrimaryName(item),
    sex: item.sex,
    birthDate: item.birthDate,
    birthPrecision: 0, // DatePrecision.Exact
    deathDate: item.deathDate,
    deathPrecision: 0,
    birthPlace: item.birthPlaceName,
    deathPlace: null,
    isVerified: false,
    needsReview: false,
    mediaCount: item.mediaCount
  };
}