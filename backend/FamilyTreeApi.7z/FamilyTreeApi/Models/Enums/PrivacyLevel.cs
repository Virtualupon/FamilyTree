namespace FamilyTreeApi.Models.Enums;

public enum PrivacyLevel
{
    Public = 0,
    FamilyOnly = 1,
    Private = 2,
    InitialsOnly = 3
}
