namespace FamilyTreeApi.Models.Enums;

public enum MediaKind
{
    Image = 0,
    Video = 1,
    Audio = 2,
    Document = 3
}
